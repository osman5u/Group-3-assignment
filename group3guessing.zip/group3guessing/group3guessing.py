import math
'''
this is a guessing game design by Group3 members wherein the program will prompt user to enter number of players 
and select number between 1--200. the winning is base on if the person enter a prime number or perfect square the 
person ear himself or herself 2marks but if the person didn't, the person earn 0marks.

Members of Group 3
1. Mohamed Kamara  9020 (GROUP LEADER)
2. Unisa Morlor Conteh 8008
3. Maada Sam Sandy
4. Mohamed Korka Jalloh 8073
5. Osman Sesay 8158 
6. Kezia Duba Kanu 7097
7. Samuel Kamara   7828
8. Peter Sidikie Gbla 6297
'''
def prime_no(n):
    if n < 2:
        return False
    for i in range(2, int(math.sqrt(n)) + 1):
        if n % i == 0:
            return False
    return True

def perfect_square(n):
    per_square = int(math.sqrt(n))
    return n == per_square ** 2


def main():
    # Get the number of players
    print("##################################################################################"
          "\n#             #  WELCOME TO GROUP3 MARKS LOTTERY GAME   #                       #"
          "\n#             #   WHERE YOU CAN EARN YOURSELF 2 MARKS   #                       #"
          "\n#             #  UPON SELECTING NUMBER FROM 1---200     #                       #"
          "\n##################################################################################")
    total_players = int(input("Enter the number of players: "))

    player_scores = {}

    for player in range(1, total_players + 1):
        print(f"\nPlayer {player}'s turn:")

        # Get a number from the player within the specified range
        while True:
            user_play = int(input(f"Enter a number between 1 and 200 (inclusive) for Player {player}: "))
            if 1 <= user_play <= 200:
                break
            else:
                print("Please enter a number within 1---200.")

        # Check if the entered number is a prime number or perfect square
        if prime_no(user_play) or perfect_square(user_play):
            print("Congratulations! You earn 2 marks.")
            player_scores[player] = 2
        else:
            print("Better luck next time.")
            player_scores[player] = 0

    # Display the final scores
    print("\nFinal Scores:")
    for player, score in player_scores.items():
        print(f"Player {player}: {score} marks")


if __name__ == "__main__":
    main()
